import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import ACTIONS from '../constants/agent-actions.constant';
import {
  ICTaskModel,
  IOverTaskFEModel,
  IResponseTasks,
  ITaskBEModel,
  ITaskDayModel,
  ITaskFEModel,
  ITaskInfo,
  ITaskInfoBack,
  IUTaskModel,
  IWeight,
  IWeightObject,
  TaskType,
  TypeTask,
} from '../models/task.model';
import {map} from 'rxjs/operators';
import moment from 'moment';
import {IDictionaryModel, IDictionaryWorkTypeModel} from '../models/dictionary.model';
import {DATE_FORMAT, DATE_FORMAT_BE} from '../constants/format.constant';
import {ICheckWorkcostOrEndDateReq} from './request.models';

interface IBasicRequestParams {
  action: string;
  userUUID: string;
  period?: {
    start: string;
    end: string;
  };
}

interface IBasicRequestsBody {
  userUUID: string;
  StartDate?: string;
  EndDate?: string;
}

@Injectable({
  providedIn: 'root',
})
export class TasksService {
  private url = '/sd/services/rest/exec-post';

  constructor(private http: HttpClient) {
  }

  getMonthProgress(id, date): Observable<any> {
    return this.http.post<string>(`${this.url}`, {
      userUUID: id,
      date,
    }, {
      responseType: 'text' as any,
      params: {
        func: ACTIONS.PROGRESS_MONTH,
      },
    });
  }

  /**
   * Метод получения списка типов работ
   */
  getWorkTypeList(id: string): Observable<IDictionaryWorkTypeModel[]> {
    return this.getBasicRequests<any[]>({
      action: ACTIONS.FIND_WORK_TYPES,
      userUUID: id,
    }).pipe(
        map(response => {
          return response.map(item => {
            return <IDictionaryWorkTypeModel>{
              title: item.title,
              code: item.code,
              uuid: item.UUID
            };
          });
        })
    );
  }
  /**
   * Метод получения списка ЗПР
   */
  getWorkList(id: string): Observable<IDictionaryModel[]> {
    return this.getBasicRequests<IDictionaryModel[]>({
      action: ACTIONS.FIND_WORK,
      userUUID: id,
    });
  }

  /**
   * Метод получения списка ЗНИ
   */
  getZniList(id: string): Observable<IDictionaryModel[]> {
    return this.getBasicRequests<IDictionaryModel[]>({
      action: ACTIONS.FIND_ZNI,
      userUUID: id,
    });
  }

  /**
   * Метод получения списка ЗНО
   */
  getZnoList(id: string): Observable<IDictionaryModel[]> {
    return this.getBasicRequests<IDictionaryModel[]>({
      action: ACTIONS.FIND_ZNO,
      userUUID: id,
    });
  }

  /**
   * Метод получения списка релизов
   */
  getReleaseList(id: string): Observable<IDictionaryModel[]> {
    return this.getBasicRequests<IDictionaryModel[]>({
      action: ACTIONS.FIND_RELEASE,
      userUUID: id,
    });
  }

  /**
   * Метод получения списка TZT
   * */
  getListTZT(userUUID: string, date: string): Observable<any> {
    return this.http.post<string>(`${this.url}`, {
      userUUID: userUUID,
      date: date
    }, {
      params: {
        func: ACTIONS.LIST_TZT,
      },
    });
  }

  /**
   * Метод получения объекта
   */
  searchDictionaryObject(objNumber: string, userId: string): Observable<any> {
    return this.http.post<string>(`${this.url}`, {
      number: objNumber,
      userUUID: userId
    }, {
      params: {
        func: ACTIONS.FIND_OBJECT_BY_NUMBER,
      },
    });
  }

  /**
   * Метод получения план-факта
   */
  getProgressDay(id: string, start: string, end: string): Observable<any> {
    return this.http.post<string>(`${this.url}`, {
      userUUID: id,
      StartDate: start,
      EndDate: end,
    }, {
      params: {
        func: ACTIONS.PLAN_FACT,
      },
    });
  }

  /**
   * Метод удаления задачи
   */
  public removeTask(taskId: string): Observable<any> {
    return this.http.post<string>(`${this.url}`, {
      taskUUID: taskId
    }, {
      params: {
        func: ACTIONS.TASK_REMOVE,
      },
    });
  }

  /**
   * Метод создания свурхурочных
   */
  createOvertime(userId: string, date: string): Observable<any> {
    return this.http.post<any>(`${this.url}`, {userUUID: userId, startDate: date}, {
      params: {
        func: ACTIONS.CREATE_OVERTIME,
      },
    });
  }

  /**
   * Метод остановки TZT
   */
  stopTZT(id: string): Observable<any> {
    return this.http.post<any>(`${this.url}`, {taskUUID: id}, {
      params: {
        func: ACTIONS.TASK_STOP,
      },
    });
  }

  /**
   * Метод старта TZT
   */
  startTZT(id: string): Observable<any> {
    return this.http.post<any>(`${this.url}`, {taskUUID: id}, {
      params: {
        func: ACTIONS.TASK_START,
      },
    });
  }

  /**
   * Получение выходных дней
   */
  getDayOff(id: string, start: string, end: string): Observable<string> {
    return this.http.post<string>(`${this.url}`, {
      userUUID: id,
      StartDate: start,
      EndDate: end,
    }, {
      params: {
        func: ACTIONS.OFF_DAYS,
      },
    });
  }

  /**
   * Получение выходных дней
   */
  getDayExtra(id: string, start: string, end: string): Observable<string> {
    return this.http.post<string>(`${this.url}`, {
      userUUID: id,
      StartDate: start,
      EndDate: end,
    }, {
      params: {
        func: ACTIONS.OVER_DAYS,
      },
    });
  }

  /**
   * Метод получения списка задач пользователя
   */
  getUserTasks(id: string, start: string, end: string, weekNumbers: number[]): Observable<IResponseTasks> {
    const date = moment(start, DATE_FORMAT);
    const offset = date.startOf('month').weekday();
    const postOffset = 6 - date.endOf('month').weekday();
    const startOffset = moment(date.startOf('month')).add(-offset, 'day');
    const endOffset = moment(date.endOf('month')).add(postOffset, 'day');

    return this.getBasicRequests<ITaskBEModel[]>({
      action: ACTIONS.USER_TASKS,
      userUUID: id,
      period: {
        start,
        end,
      },
    }).pipe(map((data: ITaskBEModel[]) => {
      let tasks: ITaskFEModel[] = data.map((item: ITaskBEModel) => {
        const feTask: ITaskFEModel = {
          ...item,
          type: this.getTypeTask(item),
          accumulateTZT: item.accumulateTZT,
          workcost: item.workcost,
          creationDate: moment(item.creationDate, DATE_FORMAT_BE),
          endDate: moment(item.endDate, DATE_FORMAT_BE),
          lastModifiedDate: moment(item.lastModifiedDate, DATE_FORMAT_BE),
          removalDate: moment(item.removalDate, DATE_FORMAT_BE),
          startDate: moment(item.startDate, DATE_FORMAT_BE),
          link: this.getTaskLink(item),
          isOverCost: this.compaire(item.accumulateTZT, item.workcost),
        };

        return feTask;
      });

      tasks = tasks.sort((a, b) => {
        const aStart = parseInt(a.startDate.format('X'), 10);
        const bStart = parseInt(b.startDate.format('X'), 10);

        return aStart >= bStart ? 1 : -1;
      });

      const { normal, over: overTasks } = this.calcWeight(tasks);

      tasks = normal;
      const dayTasks: ITaskDayModel[][] = tasks.map((item) => {
        return this.taskToTaskByDay(item, startOffset, endOffset);
      });

      this.calcRowCell(dayTasks, overTasks, weekNumbers);

      const result: IResponseTasks = {
        tasks,
        dayTasks,
        overTasks,
      };

      return result;
    }));
  }

  /**
   * Метод получения информации по задаче
   */
  getUserTaskInfo(id: string): Observable<ITaskInfo> {
    return this.http.post<ITaskInfoBack[]>(`${this.url}`, {
      taskUUID: id,
    }, {
      params: {
        func: ACTIONS.TASK_INFO,
      },
    }).pipe(map((data: any) => {
      const mapTask = data[0].map_task[0];
      const result: ITaskInfo = {
        map_obj: data[0].map_obj[0],
        map_task: {
          ...mapTask,
          accumulateTZT_task: this.accumulateToTime(mapTask.accumulateTZT_task),
          workcost_task: mapTask.workcost_task,
          workType_task: <IDictionaryWorkTypeModel>{
            uuid: mapTask.workType?.UUID,
            title: mapTask.workType?.title,
            code: mapTask.workType?.code
          },
          activeRec: mapTask.activeRec !== 'start',
        },
      };

      return result;
    }));
  }

  /**
   * Метод запуска работ
   */
  startTask(id: string): Observable<any> {
    return this.http.post<ITaskInfoBack[]>(`${this.url}`, {
      taskUUID: id,
    }, {
      params: {
        func: ACTIONS.TASK_START,
      },
    });
  }

  /**
   * Метод остановки работ
   */
  stopTask(id: string): Observable<any> {
    return this.http.post<ITaskInfoBack[]>(`${this.url}`, {
      taskUUID: id,
    }, {
      params: {
        func: ACTIONS.TASK_STOP,
      },
    });
  }

  /**
   * Метод создания задачи
   */
  createTask(data: ICTaskModel): Observable<any> {
    return this.http.post<any>(`${this.url}`, data, {
      params: {
        func: ACTIONS.TASK_CREATE,
      },
    });
  }

  /**
   * Метод обновления задачи
   */
  updateTask(data: IUTaskModel): Observable<any> {
    return this.http.post<any>(`${this.url}`, data, {
      params: {
        func: ACTIONS.TASK_UPDATE,
      },
    });
  }

  /**
   * Метод проверки и расчета трудоемкости
   */

  CheckWorkcostOrEndDate(data: ICheckWorkcostOrEndDateReq): Observable<any> {
    return this.http.post<any>(`${this.url}`, data, {
      params: {
        func: ACTIONS.CHECK_WORKCOST_OR_ENDDATE
      }
    });
  }

  /**
   * Базовый метод формирования HTTP-запроса
   */
  private getBasicRequests<T>(options: IBasicRequestParams): Observable<T> {
    const params = { func: options.action };
    const body: IBasicRequestsBody = { userUUID: options.userUUID };

    if (options.period) {
      body.StartDate = options.period.start;
      body.EndDate = options.period.end;
    }

    return this.http.post<T>(`${this.url}`, body, { params });
  }

  /**
   * Метод преобразования задач в ежедневные отрезки
   */
  private taskToTaskByDay(originTask: ITaskFEModel, startD: moment.Moment, endD: moment.Moment): ITaskDayModel[] {
    const tasks: ITaskDayModel[] = [];
    const startDate = moment(startD);
    const endDate = moment(endD);
    const start = moment(originTask.startDate);
    const end = moment(originTask.endDate);
    const diffHours = moment(end).diff(start, 'hours');
    const diffDays = moment(end).diff(start, 'days') + 1;
    let title = originTask.title;
    let state = originTask.state;

    if (originTask.type === TypeTask.release) {
      title = originTask.release?.title;
      state = originTask.release?.state;
    } else if (originTask.type === TypeTask.zni) {
      title = originTask.changeReq?.title;
      state = originTask.changeReq?.state;
    } else if ((originTask.type === TypeTask.zno) || (originTask.type === TypeTask.request)) {
      title = originTask.serviceCall?.title;
      state = originTask.serviceCall?.state;
    }

    if (!diffDays && diffHours) {
      tasks.push({
        UUID: originTask.UUID,
        title: title || originTask.title,
        titleTask: originTask.titleTask || title,
        activeRec: originTask.activeRec,
        accumulateTZT: originTask.accumulateTZT,
        workcost: originTask.workcost,
        haveActions: true,
        emplTaskWork: originTask.emplTaskWork,
        date: start,
        link: originTask.link,
        isOverCost: originTask.isOverCost,
        weight: originTask.weight,
        state: state || originTask.state,
        workType: originTask.workType,
        type: originTask.type
      });
    } else {
      let isFirst = true;

      for (let i = 0; i < diffDays; i++) {
        const date = moment(start).add(i, 'day');
        const startDiff = startDate.diff(date) > 0;
        const endDiff = endDate.diff(date) < 0;

        if (startDiff) {
          continue;
        } else {
          isFirst = false;
        }

        if (endDiff) {
          continue;
        }

        tasks.push({
          UUID: originTask.UUID,
          title: title || originTask.title,
          titleTask: originTask.titleTask || title,
          activeRec: originTask.activeRec,
          accumulateTZT: originTask.accumulateTZT,
          workcost: originTask.workcost,
          haveActions: true,
          emplTaskWork: originTask.emplTaskWork,
          date: moment(start).add(i, 'day'),
          link: originTask.link,
          isOverCost: originTask.isOverCost,
          weight: originTask.weight,
          state: state || originTask.state,
          workType: originTask.workType,
          type: originTask.type,
        });
      }
    }

    return tasks;
  }

  private accumulateToTime(accumulate: number): string {
    const duration = moment.duration(accumulate);
    const h = Math.floor(duration.asHours());
    const m = Math.floor(duration.asMinutes() - h * 60);

    return `${h < 10 ? `0${h}` : h}:${m < 10 ? `0${m}` : m}`;
  }

  private costToTime(cost: number): string {
    const h = Math.floor(cost);
    const m = Math.floor((cost - h) * 60);

    return `${h < 10 ? `0${h}` : h}:${m < 10 ? `0${m}` : m}`;
  }

  private compaire(accumulate: number, cost: number): boolean {
    const accumulateMin = moment.duration(accumulate).asHours();

    return accumulateMin > cost;
  }

  /**
   * Метод расчета весов
   */
  private calcWeight(tasks: ITaskFEModel[]): { normal: ITaskFEModel[], over: IOverTaskFEModel[] } {
    const weights: IWeightObject = {};

    tasks.forEach((task) => {
      const dateStr = task.startDate.format(DATE_FORMAT);
      let targetWeights = weights[dateStr];

      if (!targetWeights) {
        weights[dateStr] = this.newWeights();
        targetWeights = weights[dateStr];
      }

      const freeWeight = this.findFreeWeights(targetWeights);

      task.length = moment(task.endDate).diff(task.startDate, 'days') + 1;
      task.weight = freeWeight;

      for (let i = 0; i < task.length; i++) {
        const stepDateStr = moment(task.startDate).add(i, 'day').format(DATE_FORMAT);
        let stepTargetWeights = weights[stepDateStr];

        if (!stepTargetWeights) {
          weights[stepDateStr] = this.newWeights();
          stepTargetWeights = weights[stepDateStr];
        }

        stepTargetWeights[freeWeight] = false;
      }
    });

    const normal = tasks.filter((item) => {
      return item.weight < 4;
    });
    const over = tasks.filter((item) => {
      return item.weight === 4;
    }).map((item) => {
      let type: TaskType = 'request';
      let title = item.title;

      if (item.release) {
        type = TypeTask.release;
        title = item.release.title;
      } else if (item.changeReq) {
        type = TypeTask.zni;
        title = item.changeReq.title;
      } else if (item.serviceCall) {
        type = (item.serviceCall.metaClass === 'workCall') ? TypeTask.request : TypeTask.zno;
        title = item.serviceCall.title;
      }

      item.type = type;
      item.title = title;

      return item;
    });
    const group = this.groupBy(over, (val: ITaskFEModel) => {
      return val.startDate.format(DATE_FORMAT);
    });
    const overResult: IOverTaskFEModel[] = [];

    for (const key in group) {
      if (group.hasOwnProperty(key)) {
        const overTask: IOverTaskFEModel = {
          startDate: moment(key, 'DD.MM.YYYY'),
          children: group[key],
          row: 0,
          column: 0,
        };

        overResult.push(overTask);
      }
    }

    return { normal, over: overResult };
  }

  private calcRowCell(tasks: ITaskDayModel[][], over: IOverTaskFEModel[], weekNumbers: number[]): void {
    tasks.forEach((dayTasks: ITaskDayModel[]) => {
      if (dayTasks.length) {
        dayTasks.forEach((dayTask, index) => {
          const date = dayTask.date;
          const week = date.week();
          const column = date.day() === 0 ? 6 : date.day() - 1;
          const row = weekNumbers.indexOf(week);

          if (row >= 0 && column >= 0) {
            dayTask.index = index;
            dayTask.row = row;
            dayTask.column = column;
          }
        });
      }
    });

    over.forEach((task) => {
      const date = task.startDate;
      const week = date.week();
      const column = date.day() === 0 ? 6 : date.day() - 1;
      const row = weekNumbers.indexOf(week);

      if (row >= 0 && column >= 0) {
        task.row = row;
        task.column = column;
      }
    });
  }

  private newWeights(): IWeight {
    return {
      0: true,
      1: true,
      2: true,
      3: true,
    };
  }

  private groupBy(xs: any[], key: string | ((val: any) => any)): any {
    return xs.reduce((rv, x) => {
      if (typeof key === 'string') {
        (rv[x[key]] = rv[x[key]] || []).push(x);
      }
      if (typeof key === 'function') {
        const result = key(x);

        (rv[result] = rv[result] || []).push(x);
      }
      return rv;
    }, {});
  }

  private findFreeWeights(weights: any): number {
    const keys = Object.keys(weights);

    for (let i = 0; i < keys.length; i++) {
      if (weights[keys[i]]) {
        return i;
      }
    }

    return 4;
  }

  private getTaskLink(originTask: ITaskBEModel): string {
    if (originTask.release) {
      return `/sd/operator/?anchor=uuid:${originTask.release.UUID}`;
    } else if (originTask.changeReq) {
      return `/sd/operator/?anchor=uuid:${originTask.changeReq.UUID}`;
    } else if (originTask.serviceCall) {
      return `/sd/operator/?anchor=uuid:${originTask.serviceCall.UUID}`;
    }
  }

  private getTypeTask(originTask: ITaskBEModel): TaskType {
    if (originTask.release) {
      return TypeTask.release;
    }

    if (originTask.changeReq) {
      return TypeTask.zni;
    }

    if (originTask.serviceCall) {
      return originTask.serviceCall.metaClass === 'workCall' ? TypeTask.request : TypeTask.zno;
    }

    return TypeTask.zno;
  }
}
