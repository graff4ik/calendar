export interface ICheckWorkcostOrEndDateReq {
    userUUID: string;
    workCost: number;
    hourPerDay: number;
    startDate: string;
    endDate: string;
    calcEnd: string;
}
