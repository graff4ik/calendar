export interface IReleaseModel {
  title: string;
  description: string;
  state: string;
}
