export interface IDictionaryModel {
  uuid: string;
  title: string;
  responsibleType: string;
  alientask: string;
}

export interface IDictionaryWorkTypeModel {
  uuid: string;
  title: string;
  code: number;
}

export interface IFoundedObject extends IDictionaryModel{
  type: string;
}
