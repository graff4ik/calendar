import moment from 'moment';
import {IOverTaskFEModel, IResponsePlanFacts, ITaskDayModel, ITaskFEModel} from './task.model';

export interface ICalendarData {
  date: moment.Moment;
  planFacts: IResponsePlanFacts[];
  tasks: ITaskFEModel[];
  dayTasks: ITaskDayModel[][];
  overTasks: IOverTaskFEModel[];
  offDays: string[];
  extraDays: string[];
}
