import moment from 'moment';
import {IDictionaryWorkTypeModel} from './dictionary.model';

export type TaskType = 'release' | 'zni' | 'request' | 'zno';
export type OBJECT_TYPE = 'zno' | 'zni' | 'release' | 'request';

export interface IWeightObject {
  [key: string]: {
    0: boolean;
    1: boolean;
    2: boolean;
    3: boolean;
  };
}

export interface IWeight {
  0: boolean;
  1: boolean;
  2: boolean;
  3: boolean;
}

export interface ITaskParent {
  UUID: string;
  state: string;
  metaClass?: string;
  title: string;
}

export interface ITaskEmplWorkModel {
  UUID: string;
  metaClass: string;
  title: string;
}

export interface IBaseTaskModel {
  UUID: string;
  author: any;
  accumulateTZT: number;
  changeReq: ITaskParent;
  creationDate: moment.Moment;
  emplTaskWork: ITaskEmplWorkModel;
  endDate: moment.Moment;
  commentText: any;
  folders: any[];
  hourPerDay: number;
  linkReplace: any;
  metaClass: string;
  notChange: any;
  number: any;
  release: ITaskParent;
  removed: false;
  replacementEmp: any;
  serviceCall: ITaskParent;
  startDate: moment.Moment;
  state: string;
  stateStartTime: string;
  system_icon: any;
  title: string;
  titleTask: string;
  workcost: number;
  activeRec: string;
  workType: IDictionaryWorkTypeModel[];
}

export interface ITaskBEModel extends IBaseTaskModel {
  accumulateTZT: number;
  creationDate: moment.Moment;
  endDate: moment.Moment;
  lastModifiedDate: string;
  removalDate: any;
  startDate: moment.Moment;
  workcost: number;
}

export interface ITaskFEModel extends IBaseTaskModel {
  accumulateTZT: number;
  creationDate: moment.Moment;
  endDate: moment.Moment;
  lastModifiedDate: moment.Moment;
  removalDate: moment.Moment;
  startDate: moment.Moment;
  workcost: number;
  isOverCost: boolean;
  link: string;
  type?: TaskType;
  length?: number;
  weight?: number;
}

export interface IOverTaskFEModel {
  startDate: moment.Moment;
  row: number;
  column: number;
  children: ITaskFEModel[];
}

export interface ITaskDayModel {
  UUID: string;
  title: string;
  titleTask: string;
  activeRec: string;
  accumulateTZT: number;
  workcost: number;
  date: moment.Moment;
  haveActions: boolean;
  emplTaskWork: ITaskEmplWorkModel;
  type: TaskType;
  link: string;
  state?: string;
  row?: number;
  column?: number;
  weight?: number;
  index?: number;
  isLast?: boolean;
  isOverCost: boolean;
  children?: ITaskDayModel[];
  workType: IDictionaryWorkTypeModel[];
}

export interface IUTaskModel {
  startDate: string;
  endDate: string;
  workcost: number;
  hourPerDay: string;
  taskPlan: string;
  workType?: number;
  calcEnd: string;
}

export interface ITaskModelShort {
  type: string;
  start: moment.Moment;
  durationDayCount: number;
  title: string;
  uuid: string;
  work: string | null;
  obj: string;
  typeWork: string;
}

export interface ICTaskModel {
  startDate: string;
  endDate: string;
  workcost: number;
  hourPerDay: string;
  userUUID: string;
  changeReq: string;
  release: string;
  serviceCall: string;
  workType?: number;
  calcEnd: string;
}

export interface ITaskMapObj {
  TimeToImp: string;
  author: string;
  creationDate: string;
  description: string;
  priority: string;
  state: string;
  title: string;
  type: string;
  uuid: string;
}

export interface ITaskMapTask {
  accumulateTZT_task: number;
  dateEnd_task: string;
  dateStart_task: string;
  hourPerDay_task: number;
  title_task: string;
  workcost: number;
  workType_task: IDictionaryWorkTypeModel;
  workcost_task: number;
  activeRec: boolean;
}

export interface ITaskInfoBack {
  map_obj: ITaskMapObj[];
  map_task: ITaskMapTask[];
}

export interface ITaskInfo {
  map_obj: ITaskMapObj;
  map_task: ITaskMapTask;
}

export interface IResponseTasks {
  tasks: ITaskFEModel[];
  dayTasks: ITaskDayModel[][];
  overTasks: IOverTaskFEModel[];
}

export interface IResponsePlanFacts {
  date: Date;
  plan: number;
  fact: number;
}

export enum TaskStateEnum {
  Closed = 'closed',
  Registered = 'registered'
}

export enum TypeTask {
  zni= 'zni',
  zno = 'zno',
  release = 'release',
  request = 'request'
}
