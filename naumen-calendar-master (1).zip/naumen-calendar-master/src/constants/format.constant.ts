const DATE_FORMAT = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY.MM.DD HH:mm:ss';

export {
  DATE_FORMAT,
  DATE_FORMAT_BE,
};
