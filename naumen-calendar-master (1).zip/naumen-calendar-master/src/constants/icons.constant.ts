const ICON_EDIT = `<svg viewBox="64 64 896 896" focusable="false" fill="currentColor" width="1em" height="1em" data-icon="edit"
     aria-hidden="true">
    <path d="M257.7 752c2 0 4-.2 6-.5L431.9 722c2-.4 3.9-1.3 5.3-2.8l423.9-423.9a9.96 9.96 0 000-14.1L694.9 114.9c-1.9-1.9-4.4-2.9-7.1-2.9s-5.2 1-7.1 2.9L256.8 538.8c-1.5 1.5-2.4 3.3-2.8 5.3l-29.5 168.2a33.5 33.5 0 009.4 29.8c6.6 6.4 14.9 9.9 23.8 9.9zm67.4-174.4L687.8 215l73.3 73.3-362.7 362.6-88.9 15.7 15.6-89zM880 836H144c-17.7 0-32 14.3-32 32v36c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-36c0-17.7-14.3-32-32-32z"></path>
</svg>
`;
const ICON_INFO = `<svg viewBox="64 64 896 896" focusable="false" fill="currentColor" width="1em" height="1em" data-icon="info-circle"
     aria-hidden="true">
    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"></path>
    <path d="M464 336a48 48 0 1096 0 48 48 0 10-96 0zm72 112h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V456c0-4.4-3.6-8-8-8z"></path>
</svg>
`;
const ICON_PLAY = `<svg viewBox="64 64 896 896" fill="currentColor" width="1em" height="1em" data-icon="play-circle" aria-hidden="true">
    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"></path>
    <path d="M719.4 499.1l-296.1-215A15.9 15.9 0 0 0 398 297v430c0 13.1 14.8 20.5 25.3 12.9l296.1-215a15.9 15.9 0 0 0 0-25.8zm-257.6 134V390.9L628.5 512 461.8 633.1z"></path>
</svg>
`;
const ICON_STOP = `<svg viewBox="64 64 896 896" fill="currentColor" width="1em" height="1em" data-icon="pause-circle" aria-hidden="true">
    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372zm-88-532h-48c-4.4 0-8 3.6-8 8v304c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V360c0-4.4-3.6-8-8-8zm224 0h-48c-4.4 0-8 3.6-8 8v304c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V360c0-4.4-3.6-8-8-8z"></path>
</svg>
`;

const ICON_ADD_TASK = `<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="48.000000pt" height="48.000000pt" viewBox="0 0 48.000000 48.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,48.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M120 360 c-11 -11 -20 -29 -20 -40 0 -26 34 -60 60 -60 26 0 60 34
60 60 0 11 -9 29 -20 40 -11 11 -29 20 -40 20 -11 0 -29 -9 -40 -20z"/>
<path d="M280 360 c-11 -11 -20 -29 -20 -40 0 -26 34 -60 60 -60 26 0 60 34
60 60 0 11 -9 29 -20 40 -11 11 -29 20 -40 20 -11 0 -29 -9 -40 -20z"/>
<path d="M87 206 c-54 -20 -67 -34 -67 -72 l0 -34 141 0 140 0 -3 37 c-2 30
-10 41 -35 56 -43 24 -128 31 -176 13z"/>
<path d="M323 199 c10 -13 17 -40 17 -61 l0 -38 61 0 60 0 -3 37 c-4 44 -36
68 -107 79 l-44 7 16 -24z"/>
</g>
</svg>
`;

const ICON_VERIFY = `<svg xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 47.5 47.5" style="enable-background:new 0 0 47.5 47.5;" xml:space="preserve" version="1.1" id="svg2"><defs id="defs6"><clipPath id="clipPath16" clipPathUnits="userSpaceOnUse"><path id="path18" d="M 0,38 38,38 38,0 0,0 0,38 Z"/></clipPath></defs><g transform="matrix(1.25,0,0,-1.25,0,47.5)" id="g10"><g id="g12"><g clip-path="url(#clipPath16)" id="g14"><g transform="translate(37,5)" id="g20"><path id="path22" style="fill:#77b255;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 0,-2.209 -1.791,-4 -4,-4 l -28,0 c -2.209,0 -4,1.791 -4,4 l 0,28 c 0,2.209 1.791,4 4,4 l 28,0 c 2.209,0 4,-1.791 4,-4 L 0,0 Z"/></g><g transform="translate(14.5,8)" id="g24"><path id="path26" style="fill:#ffffff;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -0.64,0 -1.28,0.244 -1.768,0.732 l -6.5,6.5 c -0.976,0.977 -0.976,2.559 0,3.536 0.976,0.976 2.56,0.976 3.536,0 L 0,6.035 13.732,19.768 c 0.977,0.976 2.559,0.976 3.536,0 0.976,-0.977 0.976,-2.559 0,-3.536 L 1.768,0.732 C 1.28,0.244 0.64,0 0,0"/></g></g></g></g>
\t
\t<metadata>
\t\t<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:dc="http://purl.org/dc/elements/1.1/">
\t\t\t<rdf:Description about="https://iconscout.com/legal#licenses" dc:title="Verify, Perfect, Heavy, Check, Mark" dc:description="Verify, Perfect, Heavy, Check, Mark" dc:publisher="Iconscout" dc:date="2016-12-14" dc:format="image/svg+xml" dc:language="en">
\t\t\t\t<dc:creator>
\t\t\t\t\t<rdf:Bag>
\t\t\t\t\t\t<rdf:li>Twitter Emoji</rdf:li>
\t\t\t\t\t</rdf:Bag>
\t\t\t\t</dc:creator>
\t\t\t</rdf:Description>
\t\t</rdf:RDF>
    </metadata></svg>`;

const ICON_GROUP_PEOPLE = `<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="48.000000pt" height="48.000000pt" viewBox="0 0 48.000000 48.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,48.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M120 360 c-11 -11 -20 -29 -20 -40 0 -26 34 -60 60 -60 26 0 60 34
60 60 0 11 -9 29 -20 40 -11 11 -29 20 -40 20 -11 0 -29 -9 -40 -20z"/>
<path d="M280 360 c-11 -11 -20 -29 -20 -40 0 -26 34 -60 60 -60 26 0 60 34
60 60 0 11 -9 29 -20 40 -11 11 -29 20 -40 20 -11 0 -29 -9 -40 -20z"/>
<path d="M87 206 c-54 -20 -67 -34 -67 -72 l0 -34 141 0 140 0 -3 37 c-2 30
-10 41 -35 56 -43 24 -128 31 -176 13z"/>
<path d="M323 199 c10 -13 17 -40 17 -61 l0 -38 61 0 60 0 -3 37 c-4 44 -36
68 -107 79 l-44 7 16 -24z"/>
</g>
</svg>`;

const ICON_PEOPLE = `<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="32.000000pt" height="32.000000pt" viewBox="0 0 32.000000 32.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,32.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M122 258 c-15 -15 -15 -61 0 -76 15 -15 61 -15 76 0 15 15 15 61 0
76 -7 7 -24 12 -38 12 -14 0 -31 -5 -38 -12z"/>
<path d="M83 130 c-26 -15 -33 -27 -33 -50 l0 -30 110 0 110 0 0 30 c0 40 -47
70 -110 70 -27 0 -58 -8 -77 -20z"/>
</g>
</svg>`;

const ICON_ARROW = `<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129 129" xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 129 129">
  <g>
    <path d="m40.4,121.3c-0.8,0.8-1.8,1.2-2.9,1.2s-2.1-0.4-2.9-1.2c-1.6-1.6-1.6-4.2 0-5.8l51-51-51-51c-1.6-1.6-1.6-4.2 0-5.8 1.6-1.6 4.2-1.6 5.8,0l53.9,53.9c1.6,1.6 1.6,4.2 0,5.8l-53.9,53.9z"/>
  </g>
</svg>`;

const ICON_NEXT = `<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="32.000000pt" height="32.000000pt" viewBox="0 0 32.000000 32.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,32.000000) scale(0.100000,-0.100000)"
fill="" stroke="none">
<path d="M145 310 c-13 -21 7 -30 55 -24 43 6 51 4 74 -19 24 -24 26 -33 26
-107 0 -73 -2 -83 -25 -106 -22 -22 -33 -25 -78 -22 -41 2 -52 0 -52 -12 0
-25 123 -14 153 13 20 19 22 29 22 127 0 98 -2 108 -22 127 -26 23 -142 41
-153 23z"/>
<path d="M155 240 c-5 -8 2 -20 19 -32 42 -31 22 -40 -78 -36 -76 2 -91 0 -91
-12 0 -12 15 -14 91 -11 100 4 119 -5 79 -37 -14 -11 -25 -25 -25 -31 0 -22
26 -8 64 35 l40 45 -46 46 c-32 32 -48 42 -53 33z"/>
</g>
</svg>`;

export {
  ICON_EDIT, ICON_INFO, ICON_PLAY, ICON_STOP,
  ICON_ADD_TASK, ICON_VERIFY, ICON_PEOPLE, ICON_GROUP_PEOPLE,
  ICON_ARROW, ICON_NEXT
};
