const ERRORS = {
  NOT_FOUND_USER: 'Ошибка получения пользователя, используется тестовый',
  GET_USER_TASKS: 'Ошибка получения задач пользователя',
  GET_USER_TASK_INFO: 'Ошибка получения информации по задаче пользователя',
  DICTIONARY_LIST: 'Ошибка получения данных с сервера!',
  TASK_CREATE: 'Ошибка создания задачи',
  TASK_UPDATE: 'Ошибка обновления задачи',
};

export default ERRORS;
