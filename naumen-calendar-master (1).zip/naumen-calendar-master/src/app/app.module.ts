import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import 'moment/locale/ru';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NZ_DATE_CONFIG, NZ_I18N, ru_RU } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import ru from '@angular/common/locales/ru';
import { InfoModalComponent } from './modals/info-modal/info-modal.component';
import { FormModalComponent } from './modals/form-modal/form-modal.component';
import {
  NzAlertModule,
  NzButtonModule,
  NzCalendarModule,
  NzDatePickerModule,
  NzDividerModule,
  NzFormModule,
  NzGridModule,
  NzInputNumberModule,
  NzLayoutModule,
  NzModalModule,
  NzNotificationModule, NzPopoverModule,
  NzRadioModule,
  NzSelectModule,
  NzSpinModule,
  NzTagModule,
  NzTypographyModule,
} from 'ng-zorro-antd';
import { AuthInterceptor } from '../http/interceptor';
import { CalendarGridComponent } from './calendar-grid/calendar-grid.component';
import {CalendarService} from './calendar-grid/calendar/calendar.service';
import { TasksModalComponent } from './modals/tasks-modal/tasks-modal.component';

registerLocaleData(ru);

@NgModule({
  declarations: [
    AppComponent,
    InfoModalComponent,
    FormModalComponent,
    CalendarGridComponent,
    TasksModalComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NzGridModule,
    NzDatePickerModule,
    NzCalendarModule,
    NzTypographyModule,
    NzModalModule,
    NzButtonModule,
    NzFormModule,
    NzRadioModule,
    ReactiveFormsModule,
    NzSelectModule,
    NzInputNumberModule,
    NzAlertModule,
    NzSpinModule,
    NzLayoutModule,
    NzDividerModule,
    NzNotificationModule,
    NzTagModule
  ],
  providers: [{
    provide: NZ_I18N,
    useValue: ru_RU
  }, {
    provide: NZ_DATE_CONFIG,
    useValue: {
      /** Specify which day is the beginning of the week (null for default, 0 for Sunday, 1 for Monday, and so on) */
      firstDayOfWeek: 1
    }
  }, {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  },
    {
      provide: CalendarService,
      useClass: CalendarService
    },
],
  bootstrap: [AppComponent]
})
export class AppModule {
}
