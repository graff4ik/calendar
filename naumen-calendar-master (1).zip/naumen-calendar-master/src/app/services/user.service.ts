import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private _userId$: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  public userId$: Observable<string>;

  set userId(id: string) {
    this._userId$.next(id);
  }

  constructor() {
    this.userId$ = this._userId$;
  }
}
