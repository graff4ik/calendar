import {Component, Input, OnInit} from '@angular/core';
import {ITaskModelShort} from '../../../models/task.model';

@Component({
  selector: 'app-tasks-modal',
  templateUrl: './tasks-modal.component.html',
  styleUrls: ['./tasks-modal.component.less']
})
export class TasksModalComponent implements OnInit {

  @Input()
  public tasks: ITaskModelShort[];

  constructor() { }

  ngOnInit(): void {
  }

}
