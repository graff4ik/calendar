import { Component, Input } from '@angular/core';
import { ITaskInfo } from 'src/models/task.model';
import { TasksService } from 'src/http/tasks.service';
import {NzModalRef, NzNotificationService} from 'ng-zorro-antd';
import {CalendarService} from '../../calendar-grid/calendar/calendar.service';

@Component({
  selector: 'app-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.less'],
})
export class InfoModalComponent {
  @Input() id: string;

  @Input() task: ITaskInfo;

  public loading = false;

  constructor(private modal: NzModalRef,
              private taskService: TasksService,
              private calendarService: CalendarService,
              private notification: NzNotificationService) {
  }

  onRemoveTask(): void {
    this.taskService.removeTask(this.id)
        .subscribe(() => {
          this.calendarService.reloadTasks();
          this.modal.destroy();
        });
  }

  play(): void {
    this.action(true);
  }

  stop(): void {
    this.action(false);
  }

  private action(toggle: boolean): void {
    const request = toggle ? this.taskService.startTask(this.id) : this.taskService.stopTask(this.id);
    const title = toggle ? 'Запуск работ' : 'Остановка работ';
    const message = toggle ? 'Запуст выполнен успешно' : 'Остановка выполнена успешно';

    this.loading = true;
    request.subscribe(() => {
      this.loading = false;
      this.task.map_task.activeRec = toggle;
      this.notification.success(title, message);
    }, (err) => {
      this.loading = false;
      this.notification.error(title, 'Ошибка выполнения запроса');
    });
  }
}
