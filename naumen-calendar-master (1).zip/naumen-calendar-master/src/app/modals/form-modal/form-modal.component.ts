import {Component, ElementRef, Input, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import * as moment from 'moment';
import { TasksService } from '../../../http/tasks.service';
import {combineLatest, EMPTY, forkJoin, Observable, of, Subject} from 'rxjs';
import ERRORS from '../../../constants/errors.constant';
import {IDictionaryModel, IDictionaryWorkTypeModel, IFoundedObject} from '../../../models/dictionary.model';
import {NzModalRef, NzNotificationService} from 'ng-zorro-antd';
import {ICTaskModel, IUTaskModel, OBJECT_TYPE, TypeTask} from '../../../models/task.model';
import { DATE_FORMAT } from '../../../constants/format.constant';
import {catchError, delay, switchMap} from 'rxjs/operators';
import {ICheckWorkcostOrEndDateReq} from '../../../http/request.models';

@Component({
  selector: 'app-form-modal',
  templateUrl: './form-modal.component.html',
  styleUrls: ['./form-modal.component.less'],
})
export class FormModalComponent implements OnInit, OnDestroy {
  private _destroy$: Subject<boolean> = new Subject<boolean>();
  loading = true;
  error: string = null;
  submitLoading = false;
  submitError: string = null;
  calcType = 'date';
  searchNumberObj: string = null;
  form: FormGroup = new FormGroup({
    type: new FormControl('zni', Validators.required),
    request: new FormControl(null),
    zni: new FormControl(null),
    zno: new FormControl(null),
    release: new FormControl(null),
    startDate: new FormControl(null, Validators.required),
    hoursPerDay: new FormControl(1, Validators.required),
    workType: new FormControl(null),
    endDate: new FormControl(null),
    workCost: new FormControl(1),
    objects: new FormControl(null)
  });
  workList: IDictionaryModel[] = [];
  znoList: IDictionaryModel[] = [];
  zniList: IDictionaryModel[] = [];
  releaseList: IDictionaryModel[] = [];
  foundedObjects$: Observable<IFoundedObject[]> = of();
  foundedObjects: IFoundedObject[] = [];
  workTypeList: IDictionaryWorkTypeModel[] = [];

  @Input() USER_ID: string;
  @Input() taskId: string;
  @Input() taskDate: Date;
  @Input() extraDays: string[] = [];

  constructor(private modal: NzModalRef,
              private service: TasksService,
              private notification: NzNotificationService) {
  }

  ngOnInit(): void {
    this.form.setValidators(this.validateForm);
    this.form.patchValue({
      startDate: this.taskDate,
      endDate: this.taskDate,
    });

    if (this.taskId) {
      this.getTaskInfo();
    } else {
      this.getDictionary();
    }

    this.form.get('type').valueChanges.subscribe(value => {
      this.foundedObjects = [];
      this.searchNumberObj = null;
      this.foundedObjects$ = of();
      this.form.patchValue({
        objects: null
      });
    });

    combineLatest([
      this.form.get('workCost').valueChanges,
      this.form.get('endDate').valueChanges
    ]).pipe(
        switchMap(([workCost, endDate]) => {
          return this.loadWorkCostAndEndDate();
        })
    ).subscribe(response => {
      this.loading = false;
      let patchData = {};
      if (this.calcType === 'cost') {
        patchData = {...patchData, endDate: moment(response.endDate).toDate()};
      } else {
        patchData = {...patchData, workCost: response.workcost};
      }
      this.form.patchValue(patchData, {emitEvent: false});
    });

    this.form.get('objects').valueChanges.subscribe(value => {
      const selectedObject = this.foundedObjects.find(item => item.uuid === value);
      if (selectedObject) {
        this.form.patchValue({
          type: selectedObject.type,
          objects: null,
          [selectedObject.type]: value
        });
        switch (selectedObject.type) {
          case TypeTask.request:
            this.workList.push(selectedObject);
            break;
          case TypeTask.zno:
            this.znoList.push(selectedObject);
            break;
          case TypeTask.zni:
            this.zniList.push(selectedObject);
            break;
          case TypeTask.release:
            this.releaseList.push(selectedObject);
            break;
        }
        this.foundedObjects = [];
        this.foundedObjects$ = of();
      }
    });
  }

  getTaskInfo(): void {
    this.service.getUserTaskInfo(this.taskId)
      .subscribe((data) => {
        const formPath: any = {
          startDate: moment(data.map_task.dateStart_task, DATE_FORMAT).toDate(),
          hoursPerDay: data.map_task?.hourPerDay_task,
          workCost: data.map_task?.workcost_task,
          workType: data.map_task?.workType_task.code
        };

        if (data.map_task.dateEnd_task) {
          formPath.endDate = moment(data.map_task.dateEnd_task, DATE_FORMAT).toDate();
        }

        switch (data.map_obj.type) {
          case 'request': {
            formPath.type = TypeTask.zni;
            formPath.zni = data.map_obj.uuid;
            break;
          }
          case 'release': {
            formPath.type = TypeTask.release;
            formPath.release = data.map_obj.uuid;
            break;
          }
          default: {
            formPath.type = TypeTask.zno;
            formPath.zno = data.map_obj.uuid;
            break;
          }
        }
        this.form.patchValue(formPath);
        this.getDictionary();
        this.loading = false;
      }, () => {
        this.error = ERRORS.GET_USER_TASK_INFO;
        this.loading = false;
      });
  }

  getDictionary(): void {
    const requests = [
      this.service.getWorkList(this.USER_ID),
      this.service.getZniList(this.USER_ID),
      this.service.getZnoList(this.USER_ID),
      this.service.getReleaseList(this.USER_ID),
      this.service.getWorkTypeList(this.USER_ID),
    ];

    forkJoin(requests)
        .pipe(
            catchError(error => of(error))
        )
        .subscribe(([workList, zniList, znoList, releaseList, workTypeList]) => {
      this.workList = workList;
      this.zniList = zniList;
      this.znoList = znoList;
      this.releaseList = releaseList;
      this.workTypeList = workTypeList;
      this.loading = false;
    }, () => {
      this.error = ERRORS.DICTIONARY_LIST;
      this.loading = false;
    });
  }

  showObjectList(type: OBJECT_TYPE): boolean {
    const formType = this.form.get('type').value;

    return formType === type;
  }

  isVisible(formFieldName: string): boolean {
    let isVisible = true;
    if (this.form.get('type').value === 'request' && formFieldName === 'workType') {
      isVisible = false;
    }
    return isVisible;
  }

  disabledStartDate(): (date: Date) => boolean {
    const extraDays = this.extraDays;

    return (current: Date): boolean => {
      const curMoment = moment(current).day();
      const now = moment().startOf('day');
      const cur = moment(current).startOf('day');
      const curStr = cur.format(DATE_FORMAT);
      const isExtra = extraDays ? extraDays.indexOf(curStr) !== -1 : false;

      if (isExtra) {
        return false;
      }

      return curMoment === 6 || curMoment === 0 || cur.diff(now) < 0;
    };
  }

  minCostValue(): number {
    return this.form.get('hoursPerDay').value;
  }

  changeCalcType(): void {
    const endControl = this.form.get('endDate');
    const costControl = this.form.get('workCost');

    switch (this.calcType) {
      case 'date': {
        endControl.enable();
        costControl.disable();
        break;
      }
      case 'cost': {
        costControl.enable();
        endControl.disable();
        break;
      }
    }
  }

  setSearchObjectNumber(numberObject: string): void {
    if (numberObject) {
      this.searchNumberObj = numberObject;
    }
  }

  onSearch(): void {
    if (this.searchNumberObj) {
      this.service.searchDictionaryObject(this.searchNumberObj, this.USER_ID)
          .subscribe(response => {
            this.foundedObjects$ = of(response);
            this.foundedObjects = response;
          }, error => {
            if (error) {
              this.notification.error('Ошибка выполнения запроса', 'Задача не найдена');
            }
          });
    }
  }

  changePerDay(): void {
    const startControl = this.form.get('startDate');
    const hoursPerDayControl = this.form.get('hoursPerDay');
    const constControl = this.form.get('workCost');
    const endControl = this.form.get('endDate');
    const perDayValue = Number(hoursPerDayControl.value);
    const startValue = moment(startControl.value);

    endControl.setValue(startValue.toDate());
    constControl.setValue(perDayValue);
    this.form.updateValueAndValidity();
  }

  changeStartDateOrCost(): void {
    const startControl = this.form.get('startDate');
    const hoursPerDayControl = this.form.get('hoursPerDay');
    const constControl = this.form.get('workCost');
    const endControl = this.form.get('endDate');
    const perDayValue = Number(hoursPerDayControl.value);
    const constValue = Number(constControl.value);
    const startValue = moment(startControl.value);
    const count = constValue / perDayValue - 1;
    const endValue = moment(startValue).add(count, 'day');

    endControl.setValue(endValue.toDate(), {emit: false});
    this.form.updateValueAndValidity();
  }

  changeEndDate(): void {
    const startControl = this.form.get('startDate');
    const hoursPerDayControl = this.form.get('hoursPerDay');
    const constControl = this.form.get('workCost');
    const endControl = this.form.get('endDate');
    const perDayValue = Number(hoursPerDayControl.value);
    const startValue = moment(startControl.value);
    const endValue = moment(endControl.value);
    const diff = endValue.diff(startValue, 'day') + 1;

    constControl.setValue(perDayValue * diff, {emit: false});
    this.form.updateValueAndValidity();
  }

  disabledEndDate(current: Date): boolean {
    const startDate = this.form.get('startDate').value;

    if (startDate) {

    } else {
      const now = moment().startOf('day');
      const cur = moment(current).startOf('day');

      return cur.diff(now) < 0;
    }
  }

  destroyModal(flag?: boolean): void {
    this.modal.destroy(flag);
  }

  submit(): void {
    const valid = this.form.valid;
    this.submitError = null;

    if (valid) {
      this.submitLoading = true;
      const data = this.form.getRawValue();
      const startDate = moment(data.startDate).format(DATE_FORMAT);
      const endDate = moment(data.endDate).format(DATE_FORMAT);
      const calcEnd = this.calcType === 'date' ? 'EndDate' : 'Workcost';

      if (this.taskId) {
        const reqData: IUTaskModel = {
          startDate,
          endDate,
          hourPerDay: data.hoursPerDay,
          workcost: data.workCost,
          taskPlan: this.taskId,
          calcEnd
        };

        if (!data.request) {
          reqData.workType = data.workType;
        }

        this.service.updateTask(reqData)
          .subscribe(() => {
            this.submitLoading = false;
            this.destroyModal(true);
          }, (err) => {
            this.submitError = err.error || err;
            this.submitLoading = false;
          });
      } else {
        const reqData: ICTaskModel = {
          startDate,
          endDate,
          hourPerDay: data.hoursPerDay,
          workcost: data.workCost,
          userUUID: this.USER_ID,
          changeReq: data.zni,
          release: data.release,
          serviceCall: data.zno || data.request,
          calcEnd
        };
        if (!data.request) {
          reqData.workType = data.workType;
        }

        this.service.createTask(reqData)
          .subscribe(() => {
            this.submitLoading = false;
            this.destroyModal(true);
          }, (err) => {
            this.submitError = err.error || err;
            this.submitLoading = false;
          });
      }
    }
  }

  private loadWorkCostAndEndDate(): Observable<any> {
    const endControl = this.form.get('endDate');
    const startDateValue = this.form.get('startDate').value;
    const hoursPerDayValue = this.form.get('hoursPerDay').value;
    const costControl = this.form.get('workCost');

    this.loading = true;
    const request = <ICheckWorkcostOrEndDateReq>{
      userUUID: this.USER_ID,
      workCost: costControl.value,
      hourPerDay: hoursPerDayValue,
      startDate:  moment(startDateValue).format(DATE_FORMAT),
      endDate: moment(endControl.value).format(DATE_FORMAT),
      calcEnd: this.calcType === 'date' ? 'EndDate' : 'Workcost'
    };
    return this.service.CheckWorkcostOrEndDate(request);
  }

  private validateForm: (control: FormGroup) => (ValidationErrors | null) = (control: FormGroup) => {
    const type: OBJECT_TYPE = control.get('type').value;
    const zni = control.get('zni').value;
    const zno = control.get('zno').value;
    const release = control.get('release').value;
    const request = control.get('request').value;
    const endDate = control.get('endDate').value;
    const workCost = control.get('workCost').value;

    if (!endDate && !workCost) {
      return { hours: true };
    }

    switch (type) {
      case TypeTask.zni: {
        return zni ? null : { objectError: true };
      }
      case TypeTask.zno: {
        return zno ? null : { objectError: true };
      }
      case TypeTask.release: {
        return release ? null : { objectError: true };
      }
      case TypeTask.request: {
        return request ? null : { objectError: true };
      }
    }
  };

  ngOnDestroy(): void {
    this._destroy$.next();
  }
}
