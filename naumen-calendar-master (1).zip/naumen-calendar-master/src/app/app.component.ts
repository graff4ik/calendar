import * as moment from 'moment';
import {Component, OnInit} from '@angular/core';
import {NzModalService, NzNotificationService} from 'ng-zorro-antd';
import {FormModalComponent} from './modals/form-modal/form-modal.component';
import {TasksService} from '../http/tasks.service';
import ERRORS from '../constants/errors.constant';
import {IOverTaskFEModel, IResponsePlanFacts, IResponseTasks, ITaskDayModel, ITaskFEModel, TypeTask} from '../models/task.model';
import {forkJoin, of} from 'rxjs';
import {ICalendarData} from '../models/calendar.model';
import {InfoModalComponent} from './modals/info-modal/info-modal.component';
import {DATE_FORMAT} from '../constants/format.constant';
import {environment} from '../environments/environment';
import {ActionEvent} from 'src/app/calendar-grid/calendar-grid.component';
import {CalendarService} from './calendar-grid/calendar/calendar.service';
import {catchError} from 'rxjs/operators';
import {UserService} from './services/user.service';

interface IJSApi {
    getCurrentUser(): {
        uuid: string; // UUID пользователя
    };
}

// tslint:disable-next-line:prefer-const
declare const jsApi: IJSApi;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.less'],
})
export class AppComponent implements OnInit {
    public typeTask = TypeTask;
    public loading = false;
    public error: string = null;
    public errorUser: string = null;
    public date: any;
    public filter: {
        taskTypes: Set<TypeTask>;
    };
    public monthProgress = '';
    public offDays: string[] = [];
    public extraDays: string[] = [];
    public planFacts: IResponsePlanFacts[] = [];
    public tasks: ITaskFEModel[] = [];
    public dayTasks: ITaskDayModel[][] = [];
    public overTasks: IOverTaskFEModel[] = [];

    public gridData: ICalendarData;
    public weekNumbers: number[] = [];

    private USER_ID: string;
    private targetDate: moment.Moment = moment();

    constructor(private service: TasksService,
                private calendarService: CalendarService,
                private userService: UserService,
                private notificationService: NzNotificationService,
                private modalService: NzModalService) {
        this.filter = {
            taskTypes: new Set([TypeTask.request, TypeTask.release, TypeTask.zni, TypeTask.zno])
        };
    }

    ngOnInit(): void {
        this.calendarService.date$.subscribe(date => {
            this.date = date.toDate();
            this.getData();
        });
        this.calendarService.needReload$.subscribe(() => this.getData());
        this.calendarService.createOvertime$.subscribe((date) => this.createOvertime(date));
        this.date = this.targetDate.toDate();
        this.getUser();
        this.getData();
    }

    getUser(): void {
        const regExpUser = /employee[\$][\d]+/g;

        if (environment.production && jsApi && jsApi.getCurrentUser) {
            const systemUser = jsApi.getCurrentUser();
            let uuid: any = systemUser.uuid.match(regExpUser);

            if (uuid && uuid.length) {
                uuid = uuid[0].replace('employee$', '');
            } else {
                console.warn('UUID not found', systemUser);
                uuid = '129805';
                this.errorUser = ERRORS.NOT_FOUND_USER;
            }

            this.USER_ID = uuid;
            this.userService.userId = uuid;
        } else {
            console.warn('jsApi not found');

            const urlString = location.href;
            const url = new URL(urlString);
            const hash = url.hash.match(regExpUser);

            if (hash && hash.length) {
                this.USER_ID = hash[0].replace('employee$', '');
            } else {
                this.USER_ID = '129805';
                this.userService.userId = this.USER_ID;
                this.errorUser = ERRORS.NOT_FOUND_USER;
            }
        }
    }

    getData(): void {
        if (this.USER_ID) {
            this.changeWeekNumbers();
            const start = moment(this.date).startOf('month').format(DATE_FORMAT);
            const end = moment(this.date).endOf('month').format(DATE_FORMAT);
            const startTime = moment(this.date).startOf('month')
                .set('minute', 0)
                .set('hour', 0)
                .format('DD.MM.YYYY HH:mm');
            const endTime = moment(this.date).endOf('month')
                .set('minute', 59)
                .set('hour', 23)
                .format('DD.MM.YYYY HH:mm');
            const requests = {
                dayOff: this.service.getDayOff(this.USER_ID, startTime, endTime),
                dayExtra: this.service.getDayExtra(this.USER_ID, start, end),
                tasks: this.service.getUserTasks(this.USER_ID, start, end, this.weekNumbers),
                planFacts: this.service.getProgressDay(
                    this.USER_ID,
                    moment(this.date).startOf('month').format('DD.MM.YYYY'),
                    moment(this.date).endOf('month').format('DD.MM.YYYY')
                ),
                monthProgress: this.service.getMonthProgress(this.USER_ID, start),
            };

            this.loading = true;
            forkJoin(requests)
                .subscribe({
                    next: (value: {
                        monthProgress: string;
                        dayOff: string[];
                        dayExtra: string[];
                        tasks: IResponseTasks;
                        planFacts: IResponsePlanFacts[];
                    }) => {
                        this.monthProgress = value.monthProgress;
                        this.offDays = value.dayOff;
                        this.extraDays = value.dayExtra;
                        this.tasks = value.tasks.tasks.filter(i => this.filter.taskTypes.has(<TypeTask> i.type));
                        this.planFacts = value.planFacts;
                        this.dayTasks = value.tasks.dayTasks
                            .map(t =>
                                t.filter(i => this.filter.taskTypes.has(<TypeTask> i.type))
                            );
                        this.overTasks = value.tasks.overTasks;
                    },
                    complete: () => {
                        this.gridData = {
                            date: this.targetDate,
                            tasks: {...this.tasks},
                            planFacts: this.planFacts,
                            overTasks: this.overTasks,
                            dayTasks: this.dayTasks,
                            offDays: this.offDays,
                            extraDays: this.extraDays,
                        };
                        this.loading = false;
                    },
                    error: () => {
                        this.error = ERRORS.GET_USER_TASKS;
                        this.loading = false;
                    },
                });
        }
    }

    changeDate(date: Date): void {
        this.date = date;
        this.targetDate = moment(date);
        this.getData();
    }

    actionTask(params: ActionEvent): void {
        this.loading = true;
        if (params.action === 'play') {
            this.service.startTask(params.id)
                .subscribe(() => {
                    this.getData();
                }, (err) => {
                    this.loading = false;
                });
        } else {
            this.service.stopTask(params.id)
                .subscribe(() => {
                    this.getData();
                }, (err) => {
                    this.loading = false;
                });
        }
    }

    onFilterTasks(val: TypeTask): void {
        this.filter.taskTypes.has(val) ? this.filter.taskTypes.delete(val) : this.filter.taskTypes.add(val);
        this.getData();
    }

    showInfo(id: string): void {
        this.loading = true;
        this.service.getUserTaskInfo(id)
            .subscribe((info) => {
                this.loading = false;
                this.modalService.create({
                    nzTitle: `Плановая задача ${info.map_task.title_task}`,
                    nzContent: InfoModalComponent,
                    nzFooter: null,
                    nzMaskClosable: false,
                    nzComponentParams: {
                        task: info,
                        id: id,
                    },
                });
            }, () => {
                this.error = ERRORS.GET_USER_TASK_INFO;
                this.loading = false;
            });
    }

    createTask(date: moment.Moment): void {
        if (this.USER_ID) {
            const modal = this.modalService.create({
                nzTitle: 'Новая задача',
                nzContent: FormModalComponent,
                nzFooter: null,
                nzMaskClosable: false,
                nzComponentParams: {
                    USER_ID: this.USER_ID,
                    extraDays: this.extraDays,
                    taskDate: date.toDate(),
                },
            });

            modal.afterClose.subscribe((result) => {
                if (result) {
                    this.getData();
                }
            });
        }
    }

    public createOvertime(date: moment.Moment): void {
        if (this.USER_ID) {
            this.service.createOvertime(this.USER_ID, date.format(DATE_FORMAT))
                .pipe(
                    catchError((resp) => {
                        this.error = resp.error;
                        return of(`Error ${resp.error}`);
                    })
                )
                .subscribe((response) => {
                    this.notificationService.success('Работа в выходной день', `Вы запланировали работу в выходной день - ${date.format(DATE_FORMAT)}`);
                    this.getData();
                });
        }
    }

    updateTask(id: string): void {
        const modal = this.modalService.create({
            nzTitle: 'Редактирование задачи',
            nzContent: FormModalComponent,
            nzFooter: null,
            nzMaskClosable: false,
            nzComponentParams: {
                USER_ID: this.USER_ID,
                extraDays: this.extraDays,
                taskId: id,
            },
        });

        modal.afterClose.subscribe((result) => {
            if (result) {
                this.getData();
            }
        });
    }

    startTZT(id: string): void {
        this.service.startTZT(id)
            .subscribe(() => this.getData());
    }

    stopTZT(id: string): void {
        this.service.stopTZT(id)
            .subscribe(() => this.getData());
    }

    private changeWeekNumbers(): void {
        const start = moment(this.date).startOf('month').week();
        const end = moment(this.date).endOf('month').week();
        const max = moment(this.date).weeksInYear();

        this.weekNumbers = this.calcWeekNumbers(start, end, max > start ? max : start);
    }

    private calcWeekNumbers(start: number, end: number, max: number): number[] {
        const weekNumbers = [];

        if (start > end) {
            for (let i = start; i <= max; i++) {
                weekNumbers.push(i);
            }

            for (let i = 1; i <= end; i++) {
                weekNumbers.push(i);
            }
        } else {
            for (let i = start; i <= end; i++) {
                weekNumbers.push(i);
            }
        }

        return weekNumbers;
    }
}
