import moment from 'moment';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import { CalendarComponent } from './calendar/calendar.component';
import { ICalendarData } from 'src/models/calendar.model';
import { ActionType } from 'src/app/calendar-grid/calendar/components/task/task.component';
import {CalendarService} from './calendar/calendar.service';
import {UserService} from '../services/user.service';

export interface ActionEvent {
  id: string;
  action: ActionType;
}

@Component({
  selector: 'app-calendar-grid',
  templateUrl: './calendar-grid.component.html',
  styleUrls: ['./calendar-grid.component.less'],
})
export class CalendarGridComponent implements OnDestroy {
  private component: CalendarComponent;

  @Input() set data(value: ICalendarData) {
    this.changeData(value);
  }

  @Input() set weekNumber(numbers: number[]) {
    this.changeWeekNumber(numbers);
  }

  @Output() addEvent: EventEmitter<moment.Moment> = new EventEmitter<moment.Moment>();
  @Output() editEvent: EventEmitter<string> = new EventEmitter<string>();
  @Output() infoEvent: EventEmitter<string> = new EventEmitter<string>();
  @Output() startTZT: EventEmitter<string> = new EventEmitter<string>();
  @Output() stopTZT: EventEmitter<string> = new EventEmitter<string>();
  @Output() actionEvent: EventEmitter<ActionEvent> = new EventEmitter<ActionEvent>();

  constructor(private el: ElementRef,
              private calendarService: CalendarService,
              private userService: UserService) {
    this.component = new CalendarComponent(el.nativeElement, {
      AddEvent: this.addEventFunc.bind(this),
      EditEvent: this.editEventFunc.bind(this),
      InfoEvent: this.infoEventFunc.bind(this),
      StartTZT: this.startTZTFunc.bind(this),
      StopTZT: this.stopTZTFunc.bind(this),
      ActionEvent: this.actionEventFunc.bind(this),
    }, this.calendarService, this.userService);

    window.addEventListener('resize', this.resize.bind(this));
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.resize.bind(this));
  }

  private changeWeekNumber(numbers: number[]): void {
    if (numbers) {
      this.component.changeWeekNumber(numbers);
    }
  }

  private changeData(data: ICalendarData): void {
    if (data) {
      this.component.changeData(data);
    }
  }

  private resize(): void {
    this.component.resize();
  }

  private addEventFunc(date: moment.Moment): void {
    this.addEvent.emit(date);
  }

  private editEventFunc(id: string): void {
    this.editEvent.emit(id);
  }

  private infoEventFunc(id: string): void {
    this.infoEvent.emit(id);
  }

  private startTZTFunc(id: string): void {
    this.startTZT.emit(id);
  }
  private stopTZTFunc(id: string): void {
    this.stopTZT.emit(id);
  }
  private actionEventFunc(id: string, type: ActionType): void {
    this.actionEvent.emit({
      id,
      action: type,
    });
  }
}
