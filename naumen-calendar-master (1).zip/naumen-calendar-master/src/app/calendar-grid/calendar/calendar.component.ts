import {DomHelper} from 'src/helpers/dom.helper';
import STYLE_CLASSES from 'src/constants/style.classes';
import moment from 'moment';
import {IOverTaskFEModel, IResponsePlanFacts, ITaskDayModel, ITaskFEModel} from 'src/models/task.model';
import {WeeksComponent} from './components/weeks.component';
import {GridComponent, IGridComponentSetParams} from './components/grid/grid.component';
import {ICalendarData} from 'src/models/calendar.model';
import {ActionType} from 'src/app/calendar-grid/calendar/components/task/task.component';
import {CalendarService} from './calendar.service';
import {UserService} from '../../services/user.service';

export interface ICalendarParams {
  AddEvent: (date: moment.Moment) => void;
  EditEvent: (id: string) => void;
  InfoEvent: (id: string) => void;
  StartTZT: (id: string) => void;
  StopTZT: (id: string) => void;
  ActionEvent: (id: string, type: ActionType) => void;
}

export class CalendarComponent {
  /** Elements */
  private readonly parent: HTMLElement;
  private wrapperElement: HTMLElement | undefined;
  private daysElement: HTMLElement | undefined;
  private weeksElement: HTMLElement | undefined;
  private gridElement: HTMLElement | undefined;

  /** Variables */
  private readonly params: ICalendarParams;
  private date: moment.Moment = moment();
  private weekNumbers: number[] = [];
  private planFacts: IResponsePlanFacts[] = [];
  private tasks: ITaskFEModel[] = [];
  private overTasks: IOverTaskFEModel[] = [];
  private dayTasks: ITaskDayModel[][] = [];
  private dayOff: string[] = [];
  private dayExtra: string[] = [];

  /** Components */
  private weeksComponent: WeeksComponent = new WeeksComponent();
  private gridComponent: GridComponent;

  constructor(parent: HTMLElement,
              params?: ICalendarParams,
              private calendarService?: CalendarService,
              userService?: UserService) {
    this.parent = parent;
    this.params = params;
    this.gridComponent = new GridComponent(calendarService, userService);

    this.initCalendarElements();
  }

  public resize(): void {
    this.drawTasks();
  }

  public changeWeekNumber(weekNumbers: number[]): void {
    this.weekNumbers = weekNumbers;
    this.weeksComponent.setNumbers(weekNumbers);
  }

  public changeData(data: ICalendarData): void {
    this.date = data.date;
    this.tasks = data.tasks;
    this.planFacts = data.planFacts;
    this.overTasks = data.overTasks;
    this.dayTasks = data.dayTasks;
    this.dayOff = data.offDays;
    this.dayExtra = data.extraDays;
    this.drawTasks();
  }

  private initCalendarElements(): void {
    const wrapperElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.WRAPPER,
    });
    DomHelper.CreateElement('div', {
      class: 'calendar-naumen-wrapper-leftArrow',
      parent: wrapperElement,
      attrs: {
        title: 'Предыдущий месяц'
      },
      events: [
        {
          key: 'click',
          cb: this.calendarNavigate.bind(this, 'prev'),
        }
      ]
    });
    const wrapperLeftElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.WRAPPER_LEFT,
      parent: wrapperElement,
    });
    const wrapperRightElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.WRAPPER_RIGHT,
      parent: wrapperElement,
    });
    DomHelper.CreateElement('div', {
      class: 'calendar-naumen-wrapper-rightArrow',
      parent: wrapperElement,
      attrs: {
        title: 'Следующий месяц'
      },
      events: [
        {
          key: 'click',
          cb: this.calendarNavigate.bind(this, 'next'),
        }
      ]
    });
    const weeksElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.WEEKS,
      parent: wrapperLeftElement,
    });
    const daysElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.DAYS,
      parent: wrapperRightElement,
    });
    const gridElement = DomHelper.CreateElement('div', {
      class: STYLE_CLASSES.GRID,
      parent: wrapperRightElement,
    });

    this.daysElement = daysElement;

    this.weeksElement = weeksElement;
    this.weeksComponent.init(this.weeksElement);


    this.gridElement = gridElement;
    this.gridComponent.init({
      date: this.date,
      parent: this.gridElement,
      planFacts: this.planFacts,
      onEdit: this.callEditEvent.bind(this),
      onInfo: this.callInfoEvent.bind(this),
      onAdd: this.callAddEvent.bind(this),
      onStartTZT: this.callStartTZT.bind(this),
      onStopTZT: this.callStopTZT.bind(this),
      onAction: this.callActionEvent.bind(this),
    });

    this.wrapperElement = wrapperElement;

    this.initWeekDays();
    this.weeksComponent.setNumbers(this.weekNumbers);
    this.parent.appendChild(this.wrapperElement);
  }

  private initWeekDays(): void {
    const weekDays: string[] = moment.localeData('ru').weekdaysMin();
    const first: string = weekDays.shift() || '';

    weekDays.push(first);

    weekDays.forEach((day) => {
      DomHelper.CreateElement('div', {
        class: STYLE_CLASSES.WEEK_DAY,
        parent: this.daysElement,
        innerText: day,
      });
    });
  }

  private drawTasks(): void {
    const params: IGridComponentSetParams = {
      date: this.date,
      dayOff: this.dayOff,
      dayExtra: this.dayExtra,
      tasks: this.dayTasks,
      planFacts: this.planFacts,
      overTasks: this.overTasks,
    };

    this.gridComponent.setCells(params);
  }

  private callActionEvent(id: string, type: ActionType): void {
    if (this.params && this.params.ActionEvent) {
      this.params.ActionEvent(id, type);
    }
  }

  private callAddEvent(date: moment.Moment): void {
    if (this.params && this.params.AddEvent) {
      this.params.AddEvent(date);
    }
  }

  private callEditEvent(id: string): void {
    if (this.params && this.params.EditEvent) {
      this.params.EditEvent(id);
    }
  }

  private callInfoEvent(id: string): void {
    if (this.params && this.params.InfoEvent) {
      this.params.InfoEvent(id);
    }
  }
  private callStartTZT(id: string): void {
    if (this.params && this.params.StartTZT) {
      this.params.StartTZT(id);
    }
  }

  private callStopTZT(id: string): void {
    if (this.params && this.params.StopTZT) {
      this.params.StopTZT(id);
    }
  }

  private calendarNavigate(arrow: 'prev' | 'next'): void {
    if (arrow === 'prev') {
      this.date = this.date.subtract(1, 'M');
    } else {
      this.date = this.date.add(1, 'M');
    }
    this.calendarService.calendarNavigate(this.date);
  }
}
