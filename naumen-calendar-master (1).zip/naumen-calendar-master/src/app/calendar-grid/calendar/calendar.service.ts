import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, of, Subject} from 'rxjs';
import {ITaskFEModel, ITaskModelShort, TypeTask} from '../../../models/task.model';
import * as moment from 'moment';
import {TasksService} from '../../../http/tasks.service';
import {NzModalService, NzNotificationService} from 'ng-zorro-antd';
import {NzModalRef} from 'ng-zorro-antd/modal/modal-ref';
import {TasksModalComponent} from '../../modals/tasks-modal/tasks-modal.component';
import {DATE_FORMAT} from '../../../constants/format.constant';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private _reloadTasks$: Subject<boolean> = new Subject();
  private _createOvertime$: Subject<moment.Moment> = new Subject();
  private _date$: Subject<moment.Moment> = new Subject();
  private _tasks$: BehaviorSubject<ITaskFEModel[]> = new BehaviorSubject<ITaskFEModel[]>([]);
  public needReload$: Observable<boolean>;
  public createOvertime$: Observable<moment.Moment>;
  public tasks$: Observable<ITaskFEModel>[];
  public date$: Subject<moment.Moment> = new Subject();
  constructor(private _taskService: TasksService,
              private notificationService: NzNotificationService,
              private modalService: NzModalService) {
    this.needReload$ = this._reloadTasks$;
    this.date$ = this._date$;
    this.createOvertime$ = this._createOvertime$;
  }

  public reloadTasks(): void {
    this._reloadTasks$.next();
  }

  public createOvertime(date: moment.Moment): void {
    this._createOvertime$.next(date);
  }

  public getTZTList(userUUID: string, date: string): Observable<ITaskModelShort[]> {
    return this._taskService.getListTZT(userUUID, date).pipe(
        map(response => {
          return response.map(item => <ITaskModelShort>{
            title: item.title,
            start: moment(item.start),
            durationDayCount: item.time,
            uuid: item.uuid,
            type: item.type,
            obj: item.obj,
            typeWork: item.typeWork
          });
        })
    );
  }

  public setTasks(tasks: ITaskFEModel[]): void {
    this._tasks$.next(tasks);
  }

  public calendarNavigate(date: moment.Moment): void {
    this._date$.next(date);
  }

  public showAllTasksByDay(tasks: ITaskModelShort[], date: moment.Moment): NzModalRef {
    return this.modalService.create({
      nzTitle: `Задачи на ${date.format(DATE_FORMAT)}`,
      nzContent: TasksModalComponent,
      nzClassName: 'tasks-modal-wrapper',
      nzFooter: null,
      nzMaskClosable: false,
      nzComponentParams: {
        tasks: tasks
      },
    });
  }

  public error(error: INotifyError): void {
    this.notificationService.error(error.title, error.message);
  }

  private getTypeOfTask(task): TypeTask {
    if (task.changeRequest) {
      return TypeTask.request;
    }

    if (task.release) {
      return TypeTask.release;
    }

    if (task.serviceCall) {
      return TypeTask.zni;
    }
  }
}

export interface INotifyError {
  title: string | 'Ошибка';
  message: string | null;
}
