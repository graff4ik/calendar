import {IOverTaskFEModel, TypeTask} from 'src/models/task.model';
import { DomHelper } from 'src/helpers/dom.helper';
import STYLE_CLASSES from 'src/constants/style.classes';
import {ICON_EDIT, ICON_INFO, ICON_NEXT, ICON_PLAY, ICON_STOP} from 'src/constants/icons.constant';
import { ActionType } from 'src/app/calendar-grid/calendar/components/task/task.component';
import {DATE_FORMAT} from '../../../../../constants/format.constant';
import * as moment from 'moment';

const rowHeight = 140;
const headerOffset = 24;

export interface ITaskOverParams {
  parent: HTMLElement;
  task: IOverTaskFEModel;
  onInfo: (id: string) => void;
  onEdit: (id: string) => void;
  onAction: (id: string, type: ActionType) => void;
}

export class TaskOverComponent {
  private readonly parent: HTMLElement;
  private readonly task: IOverTaskFEModel;
  private readonly onInfo: (id: string) => void;
  private readonly onEdit: (id: string) => void;
  private readonly onAction: (id: string, type: ActionType) => void;
  private element: HTMLElement | undefined;
  private elementTooltip: HTMLElement | undefined;

  constructor(params: ITaskOverParams) {
    this.parent = params.parent;
    this.task = params.task;
    this.onInfo = params.onInfo;
    this.onEdit = params.onEdit;
    this.onAction = params.onAction;

    this.buildElements();
  }

  public destroy(): void {
    if (this.element) {
      DomHelper.DestroyElement(this.element);
    }
  }

  private buildElements(): void {
    const width = this.parent?.offsetWidth;
    const topWeight = 4 * headerOffset;

    this.element = DomHelper.CreateElement('div', {
      class: [
        STYLE_CLASSES.TASK_WRAPPER,
        STYLE_CLASSES.TASK_WRAPPER_OVER,
      ],
      parent: this.parent,
      style: {
        top: `${(this.task.row || 0) * rowHeight + headerOffset + topWeight}px`,
        left: `${(this.task.column || 0) * (width / 7)}px`,
      },
    });

    DomHelper.CreateElement('div', {
      class: [STYLE_CLASSES.TASK_WRAPPER_OVER_LABEL],
      parent: this.element,
      innerText: this.getLabel(),
    });

    this.elementTooltip = DomHelper.CreateElement('div', {
      class: [STYLE_CLASSES.TOOLTIP],
      parent: this.element,
    });

    this.buildTasks(this.elementTooltip);
  }

  private buildTasks(tooltip: HTMLElement): void {
    this.task.children.forEach((task) => {
      const classes = [STYLE_CLASSES.TOOLTIP_TASK];

      switch (task.type) {
        case TypeTask.zni: {
          classes.push(STYLE_CLASSES.TASK_ZNI);
          break;
        }
        case TypeTask.release: {
          classes.push(STYLE_CLASSES.TASK_RELEASE);
          break;
        }
        case TypeTask.request: {
          classes.push(STYLE_CLASSES.TASK_REQUEST);
          break;
        }
      }

      const taskElement = DomHelper.CreateElement('div', {
        class: classes,
        parent: tooltip,
      });
      const titleClass = [STYLE_CLASSES.TASK_TITLE];

      if (task.isOverCost) {
        titleClass.push(STYLE_CLASSES.TASK_TITLE_DANGER);
      }

      DomHelper.CreateElement('div', {
        class: [
          STYLE_CLASSES.TASK_ACTION,
          STYLE_CLASSES.TASK_ACTION_EDIT,
        ],
        parent: taskElement,
        innerHTML: ICON_EDIT,
        events: [{
          key: 'click',
          cb: this.editTask(task.UUID),
        }],
      });

      DomHelper.CreateElement('a', {
        class: titleClass,
        parent: taskElement,
        attrs: {
          href: task?.link,
          target: '_blank',
        },
        innerText: task.title,
      });

      DomHelper.CreateElement('div', {
        class: [
          STYLE_CLASSES.TASK_ACTION,
          STYLE_CLASSES.TASK_ACTION_INFO,
        ],
        parent: taskElement,
        innerHTML: ICON_INFO,
        events: [{
          key: 'click',
          cb: this.infoTask(task.UUID),
        }],
      });

      const elementActionPlay = DomHelper.CreateElement('div', {
        class: [
          STYLE_CLASSES.TASK_ACTION,
          STYLE_CLASSES.TASK_ACTION_PLAY,
        ],
        parent: taskElement,
        innerHTML: ICON_PLAY,
        events: [{
          key: 'click',
          cb: this.actionTask(task.UUID, 'play'),
        }],
      });

      const elementActionStop = DomHelper.CreateElement('div', {
        class: [
          STYLE_CLASSES.TASK_ACTION,
          STYLE_CLASSES.TASK_ACTION_PLAY,
        ],
        parent: taskElement,
        innerHTML: ICON_STOP,
        events: [{
          key: 'click',
          cb: this.actionTask(task.UUID, 'stop'),
        }],
      });

      if (task.activeRec === 'false') {
        DomHelper.ToggleViewElement(elementActionStop, 'hide');
        DomHelper.ToggleViewElement(elementActionPlay, 'hide');
      } else {
        if (task.activeRec === 'start') {
          DomHelper.ToggleViewElement(elementActionStop, 'hide');
        }
        if (task.activeRec === 'true') {
          DomHelper.ToggleViewElement(elementActionPlay, 'hide');
        }
      }

      if (moment(task.endDate).diff(moment(task.startDate),'days') > 0) {
        DomHelper.CreateElement('div', {
          class: STYLE_CLASSES.OVER_TASK,
          innerHTML: ICON_NEXT,
          attrs: {
            title: `Дата окончания задачи ${task.endDate.format(DATE_FORMAT)}`
          },
          parent: taskElement
        });
      }
    });
  }

  private getLabel(): string {
    const length = this.task.children.length;
    let result;

    switch (length) {
      case 1:
        result = 'задача';
        break;
      case 2:
      case 3:
      case 4:
        result = 'задачи';
        break;
      default:
        result = 'задачь';
        break;
    }

    return `Еще ${this.task.children.length} ${result}...`;
  }

  private editTask(id: string): () => void {
    return () => this.onEdit(id);
  }

  private infoTask(id: string): () => void {
    return () => this.onInfo(id);
  }

  private actionTask(id: string, type: ActionType): () => void {
    return () => this.onAction(id, type);
  }
}
