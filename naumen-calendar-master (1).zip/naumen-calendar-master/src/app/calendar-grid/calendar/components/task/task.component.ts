import {ITaskDayModel, TaskStateEnum, TypeTask} from 'src/models/task.model';
import { DomHelper } from 'src/helpers/dom.helper';
import STYLE_CLASSES from 'src/constants/style.classes';
import { ICON_EDIT, ICON_INFO, ICON_PLAY, ICON_STOP } from 'src/constants/icons.constant';

const rowHeight = 140;
const headerOffset = 24;

export type ActionType = 'play' | 'stop';

export interface ITaskParams {
  parent: HTMLElement;
  task: ITaskDayModel;
  first: boolean;
  last: boolean;
  onEdit: (id: string) => void;
  onInfo: (id: string) => void;
  onStartTZT: (id: string) => void;
  onStopTZT: (id: string) => void;
  onAction: (id: string, type: ActionType) => void;
}

export class TaskComponent {
  private readonly isFirst: boolean = false;
  private readonly isLast: boolean = false;
  private readonly task: ITaskDayModel;
  private readonly parent: HTMLElement;
  private readonly onEdit: (id: string) => void;
  private readonly onInfo: (id: string) => void;
  private readonly onStart: (id: string) => void;
  private readonly onStop: (id: string) => void;
  private readonly onAction: (id: string, type: ActionType) => void;
  private element: HTMLElement | undefined;
  private elementEdit: HTMLElement | undefined;
  private elementInfo: HTMLElement | undefined;
  private elementTitle: HTMLElement | undefined;
  private elementActionPlay: HTMLElement | undefined;
  private elementActionStop: HTMLElement | undefined;

  // private elementAction: HTMLElement | undefined;

  constructor(params: ITaskParams) {
    this.parent = params.parent;
    this.task = params.task;
    this.isFirst = params.first;
    this.isLast = params.last;
    this.onEdit = params.onEdit;
    this.onInfo = params.onInfo;
    this.onStart = params.onStartTZT;
    this.onStop = params.onStopTZT;
    this.onAction = params.onAction;

    this.buildTask();
  }

  public destroy(): void {
    if (this.element) {
      DomHelper.DestroyElement(this.element);
    }
  }

  private buildTask(): void {
    if (this.parent && this.task) {
      const classes = [STYLE_CLASSES.TASK_WRAPPER];

      switch (this.task.type) {
        case TypeTask.zni: {
          classes.push(STYLE_CLASSES.TASK_ZNI);
          break;
        }
        case TypeTask.release: {
          classes.push(STYLE_CLASSES.TASK_RELEASE);
          break;
        }
        case TypeTask.request: {
          classes.push(STYLE_CLASSES.TASK_REQUEST);
          break;
        }
        case TypeTask.zno: {
          classes.push(STYLE_CLASSES.TASK_ZNO);
          break;
        }
      }

      if (this.isFirst) {
        classes.push(STYLE_CLASSES.TASK_FIRST);
      }
      if (this.isLast) {
        classes.push(STYLE_CLASSES.TASK_LAST);
      }
      if (this.task.state === TaskStateEnum.Closed) {
        classes.push(STYLE_CLASSES.TASK_CLOSED);
      }

      const width = this.parent?.offsetWidth;
      const topWeight = this.task.weight ? this.task.weight * headerOffset : 0;
      const element = DomHelper.CreateElement('div', {
        class: classes,
        parent: this.parent,
        attrs: {
          'data-key': this.task?.UUID,
        },
        style: {
          top: `${(this.task.row || 0) * rowHeight + headerOffset + topWeight}px`,
          left: `${(this.task.column || 0) * (width / 7 - 1)}px`,
        },
        events: [{
          key: 'mouseover',
          cb: this.mouseOver.bind(this),
        }, {
          key: 'mouseout',
          cb: this.mouseLeave.bind(this),
        }],
      });

      if (this.isFirst) {
        const titleClass = [STYLE_CLASSES.TASK_TITLE];

        if (this.task.isOverCost) {
          titleClass.push(STYLE_CLASSES.TASK_TITLE_DANGER);
        }

        this.elementEdit = DomHelper.CreateElement('div', {
          class: [
            STYLE_CLASSES.TASK_ACTION,
            STYLE_CLASSES.TASK_ACTION_EDIT,
          ],
          parent: element,
          innerHTML: ICON_EDIT,
          events: [{
            key: 'click',
            cb: this.editTask.bind(this),
          }],
        });
        const classesByTitle = [STYLE_CLASSES.TASK_TITLE];
        if (this.task.accumulateTZT > this.task.workcost) {
          classesByTitle.push(STYLE_CLASSES.TASK_TITLE_RED);
        }
        const elementTitle = DomHelper.CreateElement('a', {
          class: classesByTitle,
          parent: element,
          innerText: this.task?.titleTask,
          attrs: {
            href: this.task?.link,
            target: '_blank',
          },
        });
        this.elementInfo = DomHelper.CreateElement('div', {
          class: [
            STYLE_CLASSES.TASK_ACTION,
            STYLE_CLASSES.TASK_ACTION_INFO,
          ],
          parent: element,
          innerHTML: ICON_INFO,
          events: [{
            key: 'click',
            cb: this.infoTask.bind(this),
          }],
        });
        this.elementActionPlay = DomHelper.CreateElement('div', {
          class: [
            STYLE_CLASSES.TASK_ACTION,
            STYLE_CLASSES.TASK_ACTION_PLAY,
          ],
          parent: element,
          innerHTML: ICON_PLAY,
          events: [{
            key: 'click',
            cb: this.actionTask('play'),
          }],
        });
        this.elementActionStop = DomHelper.CreateElement('div', {
          class: [
            STYLE_CLASSES.TASK_ACTION,
            STYLE_CLASSES.TASK_ACTION_STOP,
          ],
          parent: element,
          innerHTML: ICON_STOP,
          events: [{
            key: 'click',
            cb: this.actionTask('stop'),
          }],
        });

        if (this.task.activeRec === 'false') {
          DomHelper.ToggleViewElement(this.elementActionStop, 'hide');
          DomHelper.ToggleViewElement(this.elementActionPlay, 'hide');
        } else {
          if (this.task.activeRec === 'start') {
            DomHelper.ToggleViewElement(this.elementActionStop, 'hide');
          }
          if (this.task.activeRec === 'true') {
            DomHelper.ToggleViewElement(this.elementActionPlay, 'hide');
          }
        }
      }

      if (element) {
        this.element = element;
      }
    }
  }

  private mouseOver(): void {
    const UUID = this.task.UUID;
    const taskElements = document.querySelectorAll(`.calendar-naumen-task-wrapper[data-key="${UUID}"`);

    this.toggleHover(taskElements);
  }

  private mouseLeave(): void {
    const UUID = this.task.UUID;
    const taskElements = document.querySelectorAll(`.calendar-naumen-task-wrapper[data-key="${UUID}"]`);

    this.toggleHover(taskElements);
  }

  private toggleHover(nodes: NodeList): void {
    nodes.forEach((node: HTMLElement) => {
      node.classList.toggle('hover');
    });
  }

  private editTask(): void {
    this.onEdit(this.task.UUID);
  }

  private infoTask(): void {
    this.onInfo(this.task.UUID);
  }

  private startTask(): void {
    this.onStart(this.task.UUID);
  }
  private actionTask(type: ActionType): () => void {
    const id = this.task.UUID;

    return () => {
      this.onAction(id, type);
    };
  }
}
