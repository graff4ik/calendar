import { DomHelper } from '../../../../helpers/dom.helper';
import STYLE_CLASSES from '../../../../constants/style.classes';

export class WeeksComponent {
  private element: HTMLElement | undefined;

  public init(element: HTMLElement): void {
    this.element = element;
  }

  public setNumbers(weekNumbers: number[]): void {
    DomHelper.ClearElement(this.element);

    DomHelper.CreateElement('div', {
      class: [
        STYLE_CLASSES.WEEK_NUMBER,
        STYLE_CLASSES.WEEK_NUMBER_OFFSET,
      ],
      parent: this.element,
    });

    weekNumbers.forEach((item) => {
      DomHelper.CreateElement('div', {
        class: STYLE_CLASSES.WEEK_NUMBER,
        parent: this.element,
        innerText: item.toString(10)
      });
    });
  }
}
