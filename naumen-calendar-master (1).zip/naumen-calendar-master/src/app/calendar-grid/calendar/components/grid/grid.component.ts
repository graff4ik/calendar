import { GridCellComponent, GridCellParams } from './grid-cell.component';
import moment from 'moment';
import { DomHelper } from 'src/helpers/dom.helper';
import { ActionType, ITaskParams, TaskComponent } from '../task/task.component';
import {IOverTaskFEModel, IResponsePlanFacts, ITaskDayModel} from 'src/models/task.model';
import { DATE_FORMAT } from 'src/constants/format.constant';
import { ITaskOverParams, TaskOverComponent } from 'src/app/calendar-grid/calendar/components/task/task-over.component';
import {CalendarService} from '../../calendar.service';
import {UserService} from '../../../../services/user.service';

export interface IGridComponentSetParams {
  date: moment.Moment;
  tasks: ITaskDayModel[][];
  overTasks: IOverTaskFEModel[];
  planFacts: IResponsePlanFacts[];
  dayOff: string[];
  dayExtra: string[];
}

export interface GridParams {
  parent: HTMLElement;
  date: moment.Moment;
  planFacts: IResponsePlanFacts[];
  onAdd: (date: moment.Moment) => void;
  onEdit: (id: string) => void;
  onInfo: (id: string) => void;
  onStartTZT: (id: string) => void;
  onStopTZT: (id: string) => void;
  onAction: (id: string) => void;
}

export class GridComponent {
  private cells: GridCellComponent[] = [];
  private tasks: ITaskDayModel[][] = [];
  private overTasks: IOverTaskFEModel[] = [];
  private taskComponents: TaskComponent[] = [];
  private overTaskComponents: TaskOverComponent[] = [];
  private element: HTMLElement | undefined;
  private date: moment.Moment | undefined;
  private dayOff: string[] = [];
  private dayExtra: string[] = [];
  private planFacts: IResponsePlanFacts[];
  private onAdd: ((date: moment.Moment) => void) | undefined;
  private onEdit: ((id: string) => void) | undefined;
  private onInfo: ((id: string) => void) | undefined;
  private onStartTZT: ((id: string) => void) | undefined;
  private onStopTZT: ((id: string) => void) | undefined;
  private onAction: ((id: string, type: string) => void) | undefined;

  constructor(private calendarService: CalendarService, private userService: UserService) {
  }
  public init(params: GridParams): void {
    this.element = params.parent;
    this.date = params.date;
    this.planFacts = params.planFacts;
    this.onAdd = params.onAdd;
    this.onEdit = params.onEdit;
    this.onInfo = params.onInfo;
    this.onStartTZT = params.onStartTZT;
    this.onStopTZT = params.onStopTZT;
    this.onInfo = params.onInfo;
    this.onAction = params.onAction;

    this.buildCells();
  }

  public setCells(params: IGridComponentSetParams): void {
    this.date = params.date;
    this.dayOff = params.dayOff;
    this.dayExtra = params.dayExtra;
    this.planFacts = params.planFacts;
    this.tasks = params.tasks;
    this.overTasks = params.overTasks;

    this.buildCells();
    this.buildTasks();
  }

  private buildCells(): void {
    DomHelper.ClearElement(this.element);

    const date = moment(this.date);
    const offset = date.startOf('month').weekday();
    const postOffset = 6 - date.endOf('month').weekday();
    const start = date.startOf('month').date();
    const end = date.endOf('month').date();

    this.cells = [];

    if (this.element) {
      for (let i = offset; i >= 1; i--) {
        const cellDate = moment(this.date).startOf('month').subtract(i, 'days');
        const param: GridCellParams = {
          parent: this.element,
          dayOff: true,
          date: cellDate,
          planFact: this.planFacts.find((item) => moment(moment(item.date).format('YYYY-MM-DD')).isSame(cellDate.format('YYYY-MM-DD')))
        };

        this.cells.push(new GridCellComponent(param, this.calendarService, this.userService));
      }
      for (let i = start; i <= end; i++) {
        const cellDate = moment(this.date).date(i);
        const strDate = cellDate.format(DATE_FORMAT);
        const isDayOff = cellDate.day() === 6 || cellDate.day() === 0 || this.dayOff.indexOf(strDate) >= 0;
        const isDayExtra = this.dayExtra.indexOf(strDate) >= 0;

        const param: GridCellParams = {
          parent: this.element,
          dayOff: isDayExtra ? false : isDayOff,
          date: moment(this.date).date(i),
          onAdd: this.onAdd,
          planFact: this.planFacts.find((item) => moment(moment(item.date).format('YYYY-MM-DD')).isSame(cellDate.format('YYYY-MM-DD')))
        };
        this.cells.push(new GridCellComponent(param, this.calendarService, this.userService));
      }
      for (let i = 1; i <= postOffset; i++) {
        const cellDate = moment(this.date).endOf('month').add(i, 'days');
        const param: GridCellParams = {
          parent: this.element,
          dayOff: true,
          date: cellDate,
          planFact: this.planFacts.find((item) => moment(moment(item.date).format('YYYY-MM-DD')).isSame(cellDate.format('YYYY-MM-DD')))
        };
        this.cells.push(new GridCellComponent(param, this.calendarService, this.userService));
      }
    }
  }

  private buildTasks(): void {
    this.clearTasks();
    if (this.tasks.length) {
      this.tasks.forEach((task) => {
        const lastIndex = task.length - 1;

        task.forEach((item, index) => {
          if (this.element) {
            const params: ITaskParams = {
              parent: this.element,
              task: item,
              first: index === 0,
              last: index === lastIndex,
              onEdit: this.editTask.bind(this),
              onInfo: this.infoTask.bind(this),
              onStartTZT: this.startTask.bind(this),
              onStopTZT: this.stopTask.bind(this),
              onAction: this.actionTask.bind(this),
            };
            const component = new TaskComponent(params);

            this.taskComponents.push(component);
          }
        });
      });
    }
    if (this.overTasks.length) {
      this.overTasks.forEach((task) => {
        const params: ITaskOverParams = {
          parent: this.element,
          task,
          onInfo: this.infoTask.bind(this),
          onEdit: this.editTask.bind(this),
          onAction: this.actionTask.bind(this),
        };
        const component = new TaskOverComponent(params);

        this.overTaskComponents.push(component);
      });
    }
  }

  private editTask(id: string): void {
    if (this.onEdit) {
      this.onEdit(id);
    }
  }

  private infoTask(id: string): void {
    if (this.onInfo) {
      this.onInfo(id);
    }
  }

  private startTask(id: string): void {
    if (this.onStartTZT) {
      this.onStartTZT(id);
    }
  }

  private stopTask(id: string): void {
    if (this.onStopTZT) {
      this.onStopTZT(id);
    }
  }

  private actionTask(id: string, type: ActionType): void {
    if (this.onAction) {
      this.onAction(id, type);
    }
  }

  private clearTasks(): void {
    this.taskComponents.forEach((component) => {
      component.destroy();
    });
  }
}
