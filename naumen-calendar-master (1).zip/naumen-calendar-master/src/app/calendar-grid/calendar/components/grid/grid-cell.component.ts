import moment from 'moment';
import {DomHelper} from '../../../../../helpers/dom.helper';
import STYLE_CLASSES from '../../../../../constants/style.classes';
import {CalendarService, INotifyError} from '../../calendar.service';
import {IResponsePlanFacts, ITaskModelShort} from '../../../../../models/task.model';
import {ICON_VERIFY} from '../../../../../constants/icons.constant';
import {UserService} from '../../../../services/user.service';
import {DATE_FORMAT} from '../../../../../constants/format.constant';
import {catchError} from 'rxjs/operators';
import {EMPTY, of} from 'rxjs';

export interface GridCellParams {
    parent: HTMLElement;
    dayOff: boolean;
    date: moment.Moment;
    planFact: IResponsePlanFacts;
    onAdd?: (date: moment.Moment) => void;
}

export class GridCellComponent {
    private readonly params: GridCellParams;
    private readonly element: HTMLElement | undefined;
    private readonly headerElement: HTMLElement | undefined;
    private headerDateElement: HTMLElement | undefined;
    private headerPlusElement: HTMLElement | undefined;
    private _uuid: string;

    constructor(params: GridCellParams,
                private calendarService: CalendarService,
                private userService: UserService) {
        this.userService.userId$.subscribe(id => this._uuid = id);
        this.params = params;
        const today = moment().startOf('day');
        const current = moment(this.params.date).startOf('day');
        const canAdd = current.diff(today) >= 0;
        const classes = [STYLE_CLASSES.GRID_CELL];

        if (params.dayOff) {
            classes.push(STYLE_CLASSES.GRID_CELL_DAY_OFF);
        }

        this.element = DomHelper.CreateElement('div', {
            class: classes,
            parent: params.parent,
        });
        this.headerElement = DomHelper.CreateElement('div', {
            class: STYLE_CLASSES.GRID_CELL_HEADER,
            parent: this.element,
        });

        if (canAdd) {
            this.headerPlusElement = DomHelper.CreateElement('div', {
                class: [
                    STYLE_CLASSES.GRID_CELL_HEADER_ACTION,
                    STYLE_CLASSES.GRID_CELL_HEADER_ADD_TASK
                ],
                attrs: {
                    title: 'Добавить'
                },
                parent: this.headerElement,
                events: [{
                    key: 'click',
                    cb: () => {
                        if (this.params.onAdd) {
                            this.params.onAdd(this.params.date);
                        }
                    }
                }]
            });
        }
        const todayUnix = moment().set({ hour: 0, minute: 0, second: 0}).unix();
        if (params.dayOff && (params.date.set({ hour: 0, minute: 0, second: 0}).unix() >= todayUnix)) {
            const overTimeWr = DomHelper.CreateElement('div', {
                class: STYLE_CLASSES.GRID_CELL_HEADER_OVERTIME_WR,
                parent: this.headerElement,
                events: [{
                    key: 'click',
                    cb: () => {
                        this.calendarService.createOvertime(this.params.date);
                    }
                }]
            });

            const overTimeButton = DomHelper.CreateElement('div', {
                class: STYLE_CLASSES.GRID_CELL_HEADER_OVERTIME_BUTTON,
                attrs: {
                    title: 'Работа в выходной день'
                },
                parent: overTimeWr
            });

            DomHelper.CreateElement('div', {
                class: STYLE_CLASSES.GRID_CELL_HEADER_OVERTIME,
                innerHTML: ICON_VERIFY,
                parent: overTimeButton
            });

            DomHelper.CreateElement('div', {
                class: STYLE_CLASSES.GRID_CELL_HEADER_OVERTIME_TEXT,
                innerText: 'Учесть работу',
                parent: overTimeButton
            });
        }

        if (this.params.planFact) {
            DomHelper.CreateElement('div', {
                class: STYLE_CLASSES.GRID_CELL_HEADER_PLAN_FACT,
                innerText: this.params.planFact ? `(ф) ${Math.floor(this.params.planFact?.fact)}/(п) ${Math.floor(this.params.planFact?.plan)}` : '',
                parent: this.headerElement
            });
        }

        this.headerDateElement = DomHelper.CreateElement('div', {
            class: STYLE_CLASSES.GRID_CELL_HEADER_DATE,
            innerText: params.date.format('DD'),
            parent: this.headerElement,
            events: [{
                key: 'click',
                cb: () => {
                    this.calendarService.getTZTList(this._uuid, this.params.date.format(DATE_FORMAT))
                        .pipe(
                            catchError(_ => {
                                this.calendarService.error(<INotifyError> {
                                    title: 'Ошибка',
                                    message: 'Не удалось загрузить список задач'
                                });
                                return of(EMPTY);
                            })
                        )
                        .subscribe((tasks: ITaskModelShort[]) => {
                            this.calendarService.showAllTasksByDay(tasks, params.date);
                        });
                }
            }]
        });
    }
}
