interface IDomEvent {
  key: string;
  cb: () => void;
}

export interface IDomOptions {
  class?: string | string[];
  parent?: HTMLElement;
  innerText?: string;
  innerHTML?: string;
  events?: IDomEvent[];
  attrs?: {
    [key: string]: string;
  };
  style?: {
    [key: string]: string;
  };
}

export class DomHelper {
  public static CreateElement(tagName: string, options?: IDomOptions): HTMLElement {
    const element = document.createElement(tagName);

    if (options) {
      if (options.class) {
        element.setAttribute('class',
          options.class instanceof Array ? options.class.join(' ') : options.class);
      }

      if (options.innerText) {
        element.innerText = options.innerText;
      }

      if (options.innerHTML) {
        element.innerHTML = options.innerHTML;
      }

      if (options.parent) {
        options.parent.appendChild(element);
      }

      if (options.attrs) {
        const attrs = options.attrs;

        for (const key in attrs) {
          if (attrs.hasOwnProperty(key)) {
            element.setAttribute(key, attrs[key]);
          }
        }
      }

      if (options.style) {
        const style = options.style;
        let styles = '';

        for (const key in style) {
          if (style.hasOwnProperty(key)) {
            styles += `${key}:${style[key]};`;
            element.setAttribute('style', styles);
          }
        }
      }

      if (options.events && options.events.length) {
        options.events.forEach((item: IDomEvent) => {
          element.addEventListener(item.key, item.cb);
        });
      }
    }

    return element;
  }

  public static ToggleViewElement(element: HTMLElement, type: 'show' | 'hide'): void {
    if (element) {
      if (type === 'show') {
        element.setAttribute('style', 'display: block');
      }
      if (type === 'hide') {
        element.setAttribute('style', 'display: none');
      }
    }
  }

  public static DestroyElement(element: HTMLElement): void {
    if (element && element.parentNode) {
      element.parentNode.removeChild(element);
    }
  }

  public static ClearElement(element: HTMLElement | undefined): void {
    if (element) {
      element.innerHTML = '';
    }
  }
}
