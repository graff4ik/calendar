import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

declare var top: {
  injectJsApi(top: any, window: Window): any;
};

if (environment.production) {
  enableProdMode();
}

if (top && top.injectJsApi) {
  top.injectJsApi(top, window);
} else {
  console.info('top not found');
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
